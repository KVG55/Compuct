﻿Imports System.Resources

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Общие сведения об этой сборке предоставляются следующим набором 
' атрибутов. Отредактируйте значения этих атрибутов, чтобы изменить
' общие сведения об этой сборке.

' Проверьте значения атрибутов сборки

<Assembly: AssemblyTitle("Compuct")> 
<Assembly: AssemblyDescription("Игра в упорядочение геометрических фигур, до заданного количества баллов, на время.")> 
<Assembly: AssemblyCompany("WareZ VK Provider")> 
<Assembly: AssemblyProduct("Compuct")> 
<Assembly: AssemblyCopyright("Copyright © WareZ VK Provider  2019")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 

'Следующий GUID служит для идентификации библиотеки типов, если этот проект будет видимым для COM
<Assembly: Guid("ff0c4245-5615-4bc8-8181-12f589f7a370")> 

' Сведения о версии сборки состоят из следующих четырех значений:
'
'      Основной номер версии
'      Дополнительный номер версии 
'   Номер сборки
'      Редакция
'
' Можно задать все значения или принять номера сборки и редакции по умолчанию 
' используя "*", как показано ниже:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.1")> 
<Assembly: AssemblyFileVersion("1.0.0.1")> 

<Assembly: NeutralResourcesLanguageAttribute("ru-RU")> 